Email Spam Classification Project
=================================

Description:
------------
This project classifies email messages as either spam or legitimate (ham) using machine learning algorithms. The dataset used is the SpamAssassin Public Corpus.

Steps:
------
1. Data Preprocessing: Emails are cleaned by removing punctuation and converting text to lowercase.
2. Feature Extraction: TF-IDF vectorization is used to convert text into numerical features.
3. Model Training: Four models are trained (Naive Bayes, Logistic Regression, SVM, Random Forest).
4. Evaluation: Models are evaluated using accuracy, precision, recall, and F1-score.

Results:
--------
The best-performing model is Logistic Regression with an accuracy of 98.20%.

Files:
------
- spam_classification.py: Python script for the project.
- spam_assassin.csv: Dataset used for training and testing.

How to Run:
-----------
1. Install required libraries: pandas, scikit-learn, numpy.
2. Run the script: `python spam_classification.py`.

Submitted by: Ashfaq Adil
Date: 02/28/2025