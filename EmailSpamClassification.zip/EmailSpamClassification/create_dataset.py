import pandas as pd

# Sample dataset
data = {
    "text": [
        "Hey, how are you? Let's meet up this weekend!",
        "Congratulations! You've won a $1000 Walmart gift card. Click here to claim your prize.",
        "Reminder: Your appointment is scheduled for tomorrow at 10 AM.",
        "URGENT: Your bank account has been compromised. Click this link to secure it.",
        "Hi, just checking in to see if you received my email."
    ],
    "label": ["ham", "spam", "ham", "spam", "ham"]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Save to CSV
df.to_csv("spam_assassin.csv", index=False)

print("Dataset saved as spam_assassin.csv")